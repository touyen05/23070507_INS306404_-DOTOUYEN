/*
 * Name: Đỗ Tố Uyên
 * Student ID: 23070507
 * Assignment: Homework 5 - SQL Queries (INS3064)
 * Date: 2026-10-11
 * Database: university_db (Homework 4)
 */

USE university_db;

/*
 * Query 1: List All Students
 * Description: Retrieves every column and every record from the students table.
 * Expected Output: Five student records with all ten columns.
 */
SELECT *
FROM students
ORDER BY id;

/*
 * Expected output based on the supplied Homework 4 sample data:
 * +----+--------------+----------------+-----------------------------+------------+--------+---------------+------+---------------+---------------------+
 * | id | student_code | full_name      | email                       | phone      | gender | date_of_birth | gpa  | department_id | created_at          |
 * +----+--------------+----------------+-----------------------------+------------+--------+---------------+------+---------------+---------------------+
 * | 1  | SV001        | Nguyễn Văn An  | an.nguyen@student.edu.vn    | 0912000001 | male   | 2004-03-15    | 3.20 | 1             | 2026-10-05 19:16:00 |
 * | 2  | SV002        | Trần Thu Trang | trang.tran@student.edu.vn   | 0912000002 | female | 2004-07-20    | 3.60 | 2             | 2026-10-05 19:16:00 |
 * | 3  | SV003        | Lê Minh Đức    | duc.le@student.edu.vn       | 0912000003 | male   | 2003-11-05    | 2.80 | 3             | 2026-10-05 19:16:00 |
 * | 4  | SV004        | Phạm Hồng Anh  | honganh.pham@student.edu.vn | 0912000004 | female | 2004-01-12    | 3.45 | 4             | 2026-10-05 19:16:00 |
 * | 5  | SV005        | Hoàng Mai Linh | linh.hoang@student.edu.vn   | 0912000005 | female | 2004-09-08    | 3.75 | 5             | 2026-10-05 19:16:00 |
 * +----+--------------+----------------+-----------------------------+------------+--------+---------------+------+---------------+---------------------+
 * (5 rows)
 */

/*
 * Query 2: Students with GPA Above 3.0
 * Description: Filters students whose GPA is strictly greater than 3.0.
 * Expected Output: Four student records with student code, name, and GPA.
 */
SELECT student_code, full_name, gpa
FROM students
WHERE gpa > 3.0
ORDER BY gpa DESC, student_code;

/*
 * Expected output based on the supplied Homework 4 sample data:
 * +--------------+----------------+------+
 * | student_code | full_name      | gpa  |
 * +--------------+----------------+------+
 * | SV005        | Hoàng Mai Linh | 3.75 |
 * | SV002        | Trần Thu Trang | 3.60 |
 * | SV004        | Phạm Hồng Anh  | 3.45 |
 * | SV001        | Nguyễn Văn An  | 3.20 |
 * +--------------+----------------+------+
 * (4 rows)
 */

/*
 * Query 3: Female Students with High GPA
 * Description: Combines gender and GPA conditions using AND.
 * Expected Output: Three female students with GPA at least 3.4.
 */
SELECT student_code, full_name, gender, gpa
FROM students
WHERE gender = 'female' AND gpa >= 3.4
ORDER BY gpa DESC, student_code;

/*
 * Expected output based on the supplied Homework 4 sample data:
 * +--------------+----------------+--------+------+
 * | student_code | full_name      | gender | gpa  |
 * +--------------+----------------+--------+------+
 * | SV005        | Hoàng Mai Linh | female | 3.75 |
 * | SV002        | Trần Thu Trang | female | 3.60 |
 * | SV004        | Phạm Hồng Anh  | female | 3.45 |
 * +--------------+----------------+--------+------+
 * (3 rows)
 */

/*
 * Query 4: Students Sorted Alphabetically
 * Description: Sorts the student list in ascending order of full name.
 * Expected Output: Five student codes and names sorted by full_name.
 */
SELECT student_code, full_name
FROM students
ORDER BY full_name ASC, student_code ASC;

/*
 * Expected output based on the supplied Homework 4 sample data:
 * +--------------+----------------+
 * | student_code | full_name      |
 * +--------------+----------------+
 * | SV005        | Hoàng Mai Linh |
 * | SV003        | Lê Minh Đức    |
 * | SV001        | Nguyễn Văn An  |
 * | SV004        | Phạm Hồng Anh  |
 * | SV002        | Trần Thu Trang |
 * +--------------+----------------+
 * (5 rows)
 */

/*
 * Query 5: Top Three Graded Enrollments
 * Description: Returns the three highest graded enrollment records; excludes ungraded records.
 * Expected Output: Three enrollment IDs, student IDs, and grades in descending grade order.
 */
SELECT id AS enrollment_id, student_id, grade
FROM enrollments
WHERE grade IS NOT NULL
ORDER BY grade DESC, id ASC
LIMIT 3;

/*
 * Expected output based on the supplied Homework 4 sample data:
 * +---------------+------------+-------+
 * | enrollment_id | student_id | grade |
 * +---------------+------------+-------+
 * | 5             | 5          | 4.00  |
 * | 12            | 2          | 4.00  |
 * | 2             | 2          | 3.70  |
 * +---------------+------------+-------+
 * (3 rows)
 */

/*
 * Query 6: Courses Containing Introduction
 * Description: Finds course names containing the word Introduction.
 * Expected Output: One matching course code and course name.
 */
SELECT course_code, course_name
FROM courses
WHERE course_name LIKE '%Introduction%'
ORDER BY course_code;

/*
 * Expected output based on the supplied Homework 4 sample data:
 * +-------------+-----------------------------+
 * | course_code | course_name                 |
 * +-------------+-----------------------------+
 * | CS101       | Introduction to Programming |
 * +-------------+-----------------------------+
 * (1 rows)
 */

/*
 * Query 7: Count Students and Sum GPA
 * Description: Calculates the number of students and the sum of their GPA values.
 * Expected Output: One summary row with total_students and total_gpa.
 */
SELECT COUNT(*) AS total_students, ROUND(SUM(gpa), 2) AS total_gpa
FROM students;

/*
 * Expected output based on the supplied Homework 4 sample data:
 * +----------------+-----------+
 * | total_students | total_gpa |
 * +----------------+-----------+
 * | 5              | 16.80     |
 * +----------------+-----------+
 * (1 rows)
 */

/*
 * Query 8: Courses with at Least Three Enrollments
 * Description: Groups enrollment records by course and keeps only courses with at least three enrollments.
 * Expected Output: Course code, course name, and enrollment count for qualifying courses.
 */
SELECT c.course_code, c.course_name, COUNT(e.id) AS enrollment_count
FROM courses AS c
JOIN enrollments AS e ON e.course_id = c.id
GROUP BY c.id, c.course_code, c.course_name
HAVING COUNT(e.id) >= 3
ORDER BY enrollment_count DESC, c.course_code ASC;

/*
 * Expected output based on the supplied Homework 4 sample data:
 * +-------------+----------------------+------------------+
 * | course_code | course_name          | enrollment_count |
 * +-------------+----------------------+------------------+
 * | ENG201      | Business English     | 4                |
 * | INS3064     | Web Development      | 4                |
 * | ACC101      | Financial Accounting | 3                |
 * +-------------+----------------------+------------------+
 * (3 rows)
 */

/*
 * Query 9: Courses and Their Instructors
 * Description: Joins each course to the instructor who teaches it using the instructor foreign key.
 * Expected Output: Five course codes, course names, and instructor names.
 */
SELECT c.course_code, c.course_name AS course_title, i.full_name AS instructor_name
FROM courses AS c
JOIN instructors AS i ON i.id = c.instructor_id
ORDER BY c.course_code ASC;

/*
 * Expected output based on the supplied Homework 4 sample data:
 * +-------------+-----------------------------+-----------------+
 * | course_code | course_title                | instructor_name |
 * +-------------+-----------------------------+-----------------+
 * | ACC101      | Financial Accounting        | Phạm Thu Hà     |
 * | BA201       | Principles of Management    | Lê Quốc Hùng    |
 * | CS101       | Introduction to Programming | Trần Thị Lan    |
 * | ENG201      | Business English            | Hoàng Ngọc Anh  |
 * | INS3064     | Web Development             | Nguyễn Văn Minh |
 * +-------------+-----------------------------+-----------------+
 * (5 rows)
 */

/*
 * Query 10: Enrollments with Student Course and Semester
 * Description: Joins enrollments with students, courses, and semesters using three foreign keys.
 * Expected Output: Fifteen enrollments with student, course, semester, and grade.
 */
SELECT e.id AS enrollment_id, s.full_name AS student_name,
       c.course_name AS course_title, sm.semester_name, e.grade
FROM enrollments AS e
JOIN students AS s ON s.id = e.student_id
JOIN courses AS c ON c.id = e.course_id
JOIN semesters AS sm ON sm.id = e.semester_id
ORDER BY e.id ASC;

/*
 * Expected output based on the supplied Homework 4 sample data:
 * +---------------+----------------+-----------------------------+---------------+-------+
 * | enrollment_id | student_name   | course_title                | semester_name | grade |
 * +---------------+----------------+-----------------------------+---------------+-------+
 * | 1             | Nguyễn Văn An  | Web Development             | Fall 2024     | 3.00  |
 * | 2             | Trần Thu Trang | Introduction to Programming | Fall 2024     | 3.70  |
 * | 3             | Lê Minh Đức    | Principles of Management    | Fall 2024     | 2.70  |
 * | 4             | Phạm Hồng Anh  | Financial Accounting        | Spring 2025   | 3.50  |
 * | 5             | Hoàng Mai Linh | Business English            | Spring 2025   | 4.00  |
 * | 6             | Nguyễn Văn An  | Business English            | Spring 2025   | 3.30  |
 * | 7             | Trần Thu Trang | Web Development             | Fall 2025     | 3.70  |
 * | 8             | Lê Minh Đức    | Financial Accounting        | Fall 2025     | 3.00  |
 * | 9             | Phạm Hồng Anh  | Principles of Management    | Fall 2025     | 3.30  |
 * | 10            | Hoàng Mai Linh | Web Development             | Spring 2026   | 3.70  |
 * | 11            | Nguyễn Văn An  | Introduction to Programming | Spring 2026   | 3.30  |
 * | 12            | Trần Thu Trang | Business English            | Spring 2026   | 4.00  |
 * | 13            | Lê Minh Đức    | Web Development             | Fall 2026     | NULL  |
 * | 14            | Phạm Hồng Anh  | Financial Accounting        | Fall 2026     | NULL  |
 * | 15            | Hoàng Mai Linh | Business English            | Fall 2026     | NULL  |
 * +---------------+----------------+-----------------------------+---------------+-------+
 * (15 rows)
 */
