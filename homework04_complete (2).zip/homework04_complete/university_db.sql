/*
Student name: ĐỖ TỐ UYÊN
Student ID: 23070507
Assignment: INS3064 - Homework 4 - University Database
Date: 2026-10-03

Purpose:
Creates a complete University Course Registration database from scratch.
The script is idempotent and can be executed repeatedly without manual cleanup.
*/

-- =========================================================
-- 1. DATABASE SETUP
-- =========================================================

-- Recreate the database so the script can be rerun safely.
DROP DATABASE IF EXISTS university_db;
CREATE DATABASE university_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
USE university_db;

-- These DROP TABLE statements make the table-creation section independently rerunnable.
-- Tables are dropped in reverse dependency order to avoid foreign-key conflicts.
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS instructors;
DROP TABLE IF EXISTS semesters;
DROP TABLE IF EXISTS departments;

-- =========================================================
-- 2. TABLES
-- =========================================================

-- Table: departments
-- Stores academic departments. Department code and name must be unique.
CREATE TABLE departments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    department_code VARCHAR(10) NOT NULL,
    department_name VARCHAR(100) NOT NULL,
    description TEXT DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Prevents duplicate department codes such as two departments using "MIS".
    CONSTRAINT uq_departments_code UNIQUE (department_code),

    -- Prevents duplicate department names.
    CONSTRAINT uq_departments_name UNIQUE (department_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table: semesters
-- Stores academic semesters and their date ranges.
CREATE TABLE semesters (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    semester_code VARCHAR(20) NOT NULL,
    semester_name VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Each semester code must identify only one semester.
    CONSTRAINT uq_semesters_code UNIQUE (semester_code),

    -- Semester names are kept unique for clear identification.
    CONSTRAINT uq_semesters_name UNIQUE (semester_name),

    -- Ensures the semester end date is later than its start date.
    CONSTRAINT ck_semesters_dates CHECK (end_date > start_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table: instructors
-- Stores instructor information. Each instructor belongs to one department.
CREATE TABLE instructors (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    instructor_code VARCHAR(20) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    gender ENUM('male', 'female', 'other') NOT NULL DEFAULT 'other',
    department_id INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Instructor code must be unique.
    CONSTRAINT uq_instructors_code UNIQUE (instructor_code),

    -- Email must be unique so one email cannot belong to two instructors.
    CONSTRAINT uq_instructors_email UNIQUE (email),

    -- Ensures every instructor references an existing department.
    -- RESTRICT prevents deleting a department that still has instructors.
    -- CASCADE keeps the reference synchronized if a department ID is updated.
    CONSTRAINT fk_instructors_department
        FOREIGN KEY (department_id)
        REFERENCES departments(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table: students
-- Stores student information. Each student has one major department.
CREATE TABLE students (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_code VARCHAR(20) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    gender ENUM('male', 'female', 'other') NOT NULL DEFAULT 'other',
    date_of_birth DATE NOT NULL,
    gpa DECIMAL(3,2) DEFAULT NULL,
    department_id INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Student code must be unique.
    CONSTRAINT uq_students_code UNIQUE (student_code),

    -- Student email must be unique.
    CONSTRAINT uq_students_email UNIQUE (email),

    -- GPA is optional, but when present it must be between 0.00 and 4.00.
    CONSTRAINT ck_students_gpa CHECK (gpa IS NULL OR (gpa >= 0.00 AND gpa <= 4.00)),

    -- Ensures each student's major references an existing department.
    -- RESTRICT protects referenced department data; CASCADE propagates ID updates.
    CONSTRAINT fk_students_department
        FOREIGN KEY (department_id)
        REFERENCES departments(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table: courses
-- Stores university courses. Each course belongs to one department and one instructor.
CREATE TABLE courses (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) NOT NULL,
    course_name VARCHAR(150) NOT NULL,
    description TEXT DEFAULT NULL,
    credits INT UNSIGNED NOT NULL DEFAULT 3,
    department_id INT UNSIGNED NOT NULL,
    instructor_id INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Course code must be unique.
    CONSTRAINT uq_courses_code UNIQUE (course_code),

    -- Keeps credit values in a realistic range.
    CONSTRAINT ck_courses_credits CHECK (credits BETWEEN 1 AND 6),

    -- Ensures every course belongs to an existing department.
    CONSTRAINT fk_courses_department
        FOREIGN KEY (department_id)
        REFERENCES departments(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    -- Ensures every course references an existing instructor.
    CONSTRAINT fk_courses_instructor
        FOREIGN KEY (instructor_id)
        REFERENCES instructors(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table: enrollments
-- Junction table implementing the many-to-many relationship between students and courses.
-- semester_id records the semester in which the registration occurs.
CREATE TABLE enrollments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id INT UNSIGNED NOT NULL,
    course_id INT UNSIGNED NOT NULL,
    semester_id INT UNSIGNED NOT NULL,
    enrollment_date DATE NOT NULL,
    grade DECIMAL(3,2) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Prevents the same student from registering for the same course twice
    -- in the same semester.
    CONSTRAINT uq_enrollments_student_course_semester
        UNIQUE (student_id, course_id, semester_id),

    -- Grade is optional for ongoing courses. If entered, it must be 0.00-4.00.
    CONSTRAINT ck_enrollments_grade
        CHECK (grade IS NULL OR (grade >= 0.00 AND grade <= 4.00)),

    -- Keeps an enrollment linked to a valid student.
    CONSTRAINT fk_enrollments_student
        FOREIGN KEY (student_id)
        REFERENCES students(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    -- Keeps an enrollment linked to a valid course.
    CONSTRAINT fk_enrollments_course
        FOREIGN KEY (course_id)
        REFERENCES courses(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    -- Keeps an enrollment linked to a valid semester.
    CONSTRAINT fk_enrollments_semester
        FOREIGN KEY (semester_id)
        REFERENCES semesters(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- 3. SAMPLE DATA
-- =========================================================

-- At least five realistic departments.
INSERT INTO departments (department_code, department_name, description) VALUES
('MIS', 'Management Information Systems', 'Information systems for business and management.'),
('CS',  'Computer Science', 'Programming, algorithms, software, and computing.'),
('BA',  'Business Administration', 'Business management and organizational studies.'),
('ACC', 'Accounting', 'Financial accounting, auditing, and reporting.'),
('ENG', 'English Language', 'English language and professional communication.');

-- At least five semesters.
INSERT INTO semesters (semester_code, semester_name, start_date, end_date) VALUES
('FALL2024',   'Fall 2024',   '2024-09-01', '2024-12-31'),
('SPRING2025', 'Spring 2025', '2025-01-15', '2025-05-31'),
('FALL2025',   'Fall 2025',   '2025-09-01', '2025-12-31'),
('SPRING2026', 'Spring 2026', '2026-01-15', '2026-05-31'),
('FALL2026',   'Fall 2026',   '2026-09-01', '2026-12-31');

-- At least five instructors using plausible Vietnamese names.
INSERT INTO instructors
(instructor_code, full_name, email, phone, gender, department_id) VALUES
('GV001', 'Nguyễn Văn Minh', 'minh.nguyen@university.edu.vn', '0901000001', 'male',   1),
('GV002', 'Trần Thị Lan',    'lan.tran@university.edu.vn',    '0901000002', 'female', 2),
('GV003', 'Lê Quốc Hùng',    'hung.le@university.edu.vn',     '0901000003', 'male',   3),
('GV004', 'Phạm Thu Hà',     'ha.pham@university.edu.vn',     '0901000004', 'female', 4),
('GV005', 'Hoàng Ngọc Anh',  'anh.hoang@university.edu.vn',   '0901000005', 'female', 5);

-- At least five students using plausible Vietnamese names.
INSERT INTO students
(student_code, full_name, email, phone, gender, date_of_birth, gpa, department_id) VALUES
('SV001', 'Nguyễn Văn An',   'an.nguyen@student.edu.vn',       '0912000001', 'male',   '2004-03-15', 3.20, 1),
('SV002', 'Trần Thu Trang',  'trang.tran@student.edu.vn',      '0912000002', 'female', '2004-07-20', 3.60, 2),
('SV003', 'Lê Minh Đức',     'duc.le@student.edu.vn',          '0912000003', 'male',   '2003-11-05', 2.80, 3),
('SV004', 'Phạm Hồng Anh',   'honganh.pham@student.edu.vn',    '0912000004', 'female', '2004-01-12', 3.45, 4),
('SV005', 'Hoàng Mai Linh',  'linh.hoang@student.edu.vn',      '0912000005', 'female', '2004-09-08', 3.75, 5);

-- At least five courses with valid department and instructor references.
INSERT INTO courses
(course_code, course_name, description, credits, department_id, instructor_id) VALUES
('INS3064', 'Web Development',              'Web application development using PHP and MySQL.',              3, 1, 1),
('CS101',   'Introduction to Programming',  'Programming fundamentals and problem solving.',                 3, 2, 2),
('BA201',   'Principles of Management',      'Planning, organizing, leading, and controlling.',               3, 3, 3),
('ACC101',  'Financial Accounting',          'Basic accounting principles and financial statements.',         3, 4, 4),
('ENG201',  'Business English',              'English communication in professional settings.',               2, 5, 5);

-- At least ten enrollments with varied student-course-semester combinations.
-- NULL grades represent courses that are still in progress.
INSERT INTO enrollments
(student_id, course_id, semester_id, enrollment_date, grade) VALUES
(1, 1, 1, '2024-09-02', 3.00),
(2, 2, 1, '2024-09-03', 3.70),
(3, 3, 1, '2024-09-04', 2.70),
(4, 4, 2, '2025-01-16', 3.50),
(5, 5, 2, '2025-01-17', 4.00),
(1, 5, 2, '2025-01-18', 3.30),
(2, 1, 3, '2025-09-02', 3.70),
(3, 4, 3, '2025-09-03', 3.00),
(4, 3, 3, '2025-09-04', 3.30),
(5, 1, 4, '2026-01-16', 3.70),
(1, 2, 4, '2026-01-17', 3.30),
(2, 5, 4, '2026-01-18', 4.00),
(3, 1, 5, '2026-09-02', NULL),
(4, 4, 5, '2026-09-03', NULL),
(5, 5, 5, '2026-09-04', NULL);

-- =========================================================
-- 4. OPTIONAL VERIFICATION QUERIES
-- =========================================================
-- These SELECT statements make it easy to verify the imported data in phpMyAdmin.
SELECT 'departments' AS table_name, COUNT(*) AS record_count FROM departments
UNION ALL
SELECT 'instructors', COUNT(*) FROM instructors
UNION ALL
SELECT 'students', COUNT(*) FROM students
UNION ALL
SELECT 'courses', COUNT(*) FROM courses
UNION ALL
SELECT 'semesters', COUNT(*) FROM semesters
UNION ALL
SELECT 'enrollments', COUNT(*) FROM enrollments;
